import Header from "../components/header/header"

export default function ProgramPage () {

    return(
        <main>
            <Header/>
            <h1>Welcome to Program Page</h1>
        </main>
       

    )
}