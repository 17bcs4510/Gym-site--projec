import Header from "../components/header/header"




export default function AboutPage () {



    return(

        <main>
            <Header/>
            <h1>
                Welcome to about page
            </h1>
        </main>
    )
}